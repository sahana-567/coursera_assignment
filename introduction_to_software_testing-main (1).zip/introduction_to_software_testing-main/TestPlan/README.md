# Building a Test Plan

The task is to develop a test plan for a software product with it's requirements specified in [SRS.pdf](./SRS.pdf).

## Solution
Developed test plan can be found in [TestPlan.pdf](./TestPlan.pdf).