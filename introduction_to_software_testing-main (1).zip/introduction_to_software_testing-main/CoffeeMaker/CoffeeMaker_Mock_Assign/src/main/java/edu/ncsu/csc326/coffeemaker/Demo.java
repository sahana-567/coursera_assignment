public class Demo {

    public static void main(String[] args){
        int[] myInt= {1, 2, 3};

        System.out.println(myInt[0]);
    }
    
}
