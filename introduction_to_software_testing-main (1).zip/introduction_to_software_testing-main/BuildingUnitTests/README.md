# Building Unit Tests with JUnit

The task is to practice building effective unit tests.

## Solution
- [Test file](./src/test/java/DemoTest.java)